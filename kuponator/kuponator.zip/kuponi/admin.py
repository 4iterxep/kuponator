from django.contrib import admin
from .models import Kuponi

# Register your models here.
admin.site.register(Kuponi)